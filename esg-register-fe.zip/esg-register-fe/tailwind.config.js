/** @type {import('tailwindcss').Config} */

import * as themeFile from './src/styles/theme.json';
import colors from "./src/styles/colorPalette.ts";

export default {
  coreplugins: {
    preflight: false,
  },
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    fontfamily: {
      'font-default': [themeFile.font.family],
    },
    extend: {
      colors: colors,
    }
  },
  prefix: 'tw-',
  plugins: []
};
