import axios from 'axios';

let authToken: string | null = null;

const apiClient = axios.create({
  baseURL: process.env.REACT_APP_BASE_URL
});

apiClient.interceptors.request.use(
  (config) => {
    if (authToken) {
      config.headers!.Authorization = `Bearer ${authToken}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

apiClient.interceptors.response.use(
  (data) => data,
  (error) => {
    return Promise.reject(error?.response?.message);
  }
);

export const setToken = (token: string) => {
  authToken = token;
}

export default apiClient;
