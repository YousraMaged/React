const colors = {
  primary: '#002EA6',
  secondary: '#000484',
  success: '#00A86B',
  warning: '#FFC72C',
  error: '#D0011B'
};

export default colors;
