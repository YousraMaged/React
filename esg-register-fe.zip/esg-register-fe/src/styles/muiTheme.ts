import { createTheme } from '@mui/material';
import themeFile from './theme.json';
import colors from './colorPalette.ts';

const theme = createTheme({
  palette: {
    primary: {
      main: colors.primary
    },
    secondary: {
      main: colors.secondary
    },
    success: {
      main: colors.success
    },
    warning: {
      main: colors.warning
    },
    error: {
      main: colors.error
    }
  },
  typography: {
    fontFamily: themeFile.font.family
  }
});

export default theme;
